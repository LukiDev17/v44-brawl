from Classes.ByteStream import ByteStream
from Database.DatabaseHandler import DatabaseHandler
import json

class StreamEntry:
    def encode(self: ByteStream, info):
        db_instance = DatabaseHandler()
        playerData = json.loads(db_instance.getPlayerEntry([info['PlayerID'][0], info['PlayerID'][1]])[2])
        
        self.writeVLong(info['StreamID'][0], info['StreamID'][1]) # StreamEntryID
        self.writeVLong(info['PlayerID'][0], info['PlayerID'][1]) # TargetID
        self.writeString(playerData['Name'])
        self.writeVInt(info['PlayerRole'])
        self.writeVInt(0)
        self.writeBoolean(False)

