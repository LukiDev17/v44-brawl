from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import TeamDatabaseHandler, DatabaseHandler
import json


class TeamInvitationMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(fields["InviterID"])[2])
        
        self.writeVInt(1)
        self.writeLong(fields["TeamID"][0], fields["TeamID"][1]) # TeamID
        
        # FriendEntry::encode
        self.writeLong(fields["InviterID"][0], fields["InviterID"][1]) # AccountID
        
        self.writeString()
        self.writeString()
        self.writeString()
        self.writeString()
        self.writeString()
        self.writeString()
        
        self.writeInt(0) # Trophies
        self.writeInt(1) # FriendState
        self.writeInt(0) # FriendReason
        self.writeInt(0) # Unk
        self.writeInt(0) # Array
        
        self.writeBoolean(True) # AllianceEntry
        
        self.writeLong(player_data["AllianceID"][0], player_data["AllianceID"][1])
        self.writeInt(1)
        self.writeString("Acavav")
        self.writeInt(1)
        self.writeInt(1)
        
        self.writeString() # Unk
        self.writeInt(99) # LastOnlineTime
        self.writeInt(19) # PowerLeague
        self.writeBoolean(True) # PlayerDisplayData Boolean
        # PlayerDisplayData::encode #
        self.writeString(player_data["Name"])
        self.writeVInt(100)
        self.writeVInt(28000000 + player_data["Thumbnail"])
        self.writeVInt(43000000 + player_data["Namecolor"])
        self.writeVInt(-1)
        
        self.writeInt(0)
        self.writeInt(0)

    def decode(self):
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24589

    def getMessageVersion(self):
        return self.messageVersion