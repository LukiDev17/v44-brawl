from Classes.Packets.PiranhaMessage import PiranhaMessage


import Configuration

from Classes.Packets.PiranhaMessage import PiranhaMessage


class StartLoadingMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 1

    def encode(self, fields, player):
        self.writeInt(1) # Player Count
        self.writeInt(0) # OwnIndex
        self.writeInt(0) # TeamIndex
        self.writeInt(1) # Players Count
        for i in range(1):
        	self.writeLong(player.ID[0], player.ID[1] + i) # PlayerID
        	self.writeVInt(i) # PlayerIndex
        	teamIndex = 0
        	if i > 2:
        		teamIndex = 1
        	self.writeVInt(teamIndex) # TeamIndex
        	self.writeVInt(0)
        	
        	self.writeInt(0)
        	self.writeBoolean(True) # HeroUpdate
        	# HeroUpdateArrayStart
        	self.writeDataReference(16, player.SelectedBrawlers[0])
        	self.writeBoolean(False) # sub_6BC5C0
        	#self.writeVInt(0)
#        	self.writeDataReference(16, 1)
#        	self.writeDataReference(0, 0)
#        	self.writeDataReference(16, 2)
#        	self.writeDataReference(0, 0)
#        	self.writeVInt(0)
#        	self.writeVInt(0)
        	self.writeBoolean(False)
        	#self.writeDataReference(0, 0)
#        	self.writeVInt(0)
        	self.writeBoolean(False)
        	#self.writeDataReference(0, 0)
#        	self.writeVInt(0)
        	
        	self.writeDataReference(0, 0)
        	# HeroUpdateArrayEnd
        	
        	self.writeString(player.Name)
        	self.writeVInt(100)
        	self.writeVInt(28000000)
        	self.writeVInt(43000000)
        	self.writeVInt(-1)
        	
        	self.writeBoolean(False)
        	
        	self.writeVInt(0)
        
        self.writeInt(0) # LogicVector2 Array
        for x in range(0):
        	self.writeInt(3177)
        	self.writeInt(1006)
        
        self.writeInt(0) # Modifiers
        
        self.writeInt(1) # Unk
        
        self.writeVInt(0) # Gamemode
        self.writeVInt(1) # DrawMap
        self.writeVInt(0)
        
        self.writeBoolean(False)
        self.writeVInt(0) # SpectateMode
        self.writeVInt(0)
        
        self.writeDataReference(15, 7) # MapID
        self.writeBoolean(False) # BattlePlayerMap
        
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)


    def decode(self):
        fields = {}
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 20559

    def getMessageVersion(self):
        return self.messageVersion