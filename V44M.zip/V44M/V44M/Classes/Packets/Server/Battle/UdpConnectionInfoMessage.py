from Classes.Packets.PiranhaMessage import PiranhaMessage


import Configuration

from Classes.Packets.PiranhaMessage import PiranhaMessage


class UdpConnectionInfoMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 1

    def encode(self, fields, player):
        self.writeVInt(9339) # Server Port
        self.writeString() # Server IP
        self.writeInt(10)
        self.writeLong(0, 1) # SessionID
        self.writeShort(0)
        
        self.writeInt(0)


    def decode(self):
        fields = {}
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24112

    def getMessageVersion(self):
        return self.messageVersion