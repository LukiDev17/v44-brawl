from Classes.Packets.PiranhaMessage import PiranhaMessage


import Configuration

from Classes.Packets.PiranhaMessage import PiranhaMessage


class MatchMakingStatusMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 1

    def encode(self, fields, player):
        self.writeInt(20) # Timer
        self.writeInt(2) # Founded Players
        self.writeInt(2) # Max Players
        self.writeInt(0)
        self.writeInt(0)
        
        self.writeBoolean(False) # Show Timer


    def decode(self):
        fields = {}
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 20405

    def getMessageVersion(self):
        return self.messageVersion