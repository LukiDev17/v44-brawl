from Classes.Packets.PiranhaMessage import PiranhaMessage


class LatencyTestStatusMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0        
    def encode(self,fields):
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeLong(0, 1)
        self.writeString("a")
        self.writeString("b")
        self.writeString("c")

    def execute(message, calling_instance, fields):
        pass
        

    def getMessageType(self):
        return 29003

    def getMessageVersion(self):
        return self.messageVersion