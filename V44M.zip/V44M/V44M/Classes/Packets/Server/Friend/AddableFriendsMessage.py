from Classes.ByteStream import ByteStream
from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler


class AddableFriendsMessage(PiranhaMessage):

    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0
        

    def encode(self, fields, player):
        self.writeInt(1)
        
        self.writeInt(1)
        self.writeInt(2)
        self.writeString("KulerDick")
        self.writeInt(0)
        self.writeString("KulerDick")


    def decode(self):
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 20107

    def getMessageVersion(self):
        return self.messageVersion
