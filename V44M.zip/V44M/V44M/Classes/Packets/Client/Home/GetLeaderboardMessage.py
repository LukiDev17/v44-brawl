from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler


class GetLeaderboardMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        fields["IsLocal"] = self.readBoolean()
        fields["Type"] = self.readVInt()
        fields["CsvID"] = self.readVInt()
        if fields["CsvID"] == 16:
        	fields["Brawler"] = self.readVInt()
        return fields

    def execute(message, calling_instance, fields):
        fields["Socket"] = calling_instance.client
        Messaging.sendMessage(24403, fields, calling_instance.player)

    def getMessageType(self):
        return 14403

    def getMessageVersion(self):
        return self.messageVersion