from Classes.ByteStream import ByteStream
from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler
from Classes.Messaging import Messaging
from Static.StaticData import StaticData
from Database.DatabaseHandler import TeamDatabaseHandler, DatabaseHandler
from Classes.Instances.Classes.Team import Team
from Classes.Utility import Utility
import json


class TeamInvitationResponseMessage(PiranhaMessage):


    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0


    def encode(self, fields, player):
        pass

    def decode(self):
        fields = {}
        fields["Response"] = self.readVInt()
        super().decode(fields)
        return fields


    def execute(message, calling_instance, fields):
        db_instance = DatabaseHandler()
        teamdb_instance = TeamDatabaseHandler()
        allTeams = teamdb_instance.getAllTeam()
        for x in allTeams:
        	if str(calling_instance.player.ID[1]) in x["Invites"]:
        		fields["TeamID"] = [x["HighID"], x["LowID"]]
        teamData = json.loads(teamdb_instance.getTeamWithLowID(fields["TeamID"][1])[0][1])
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        
        player_data["TeamID"] = fields["TeamID"]
        db_instance.updatePlayerData(player_data, calling_instance)
        del teamData["Invites"][str(calling_instance.player.ID[1])]
        teamdb_instance.updateTeamData(teamData, fields["TeamID"][1])
        if fields["Response"] == 1:
        	teamData["Members"][str(calling_instance.player.ID[1])] = {'HighID': calling_instance.player.ID[0], 'LowID': calling_instance.player.ID[1], 'Ready': False, 'Owner': False}
        	LastMessageID = len(teamData["ChatData"])
        	message = {
        	'StreamType': 4,
        	'StreamID': [0, LastMessageID + 1],
        	'PlayerID': calling_instance.player.ID,
        	'PlayerName': calling_instance.player.Name,
        	'PlayerRole': 0,
        	'EventType': 102,
        	'Target': {'ID': calling_instance.player.ID, 'Name': calling_instance.player.Name}
        	}
        	teamData["ChatData"].append(message)
        	teamdb_instance.updateTeamData(teamData, fields["TeamID"][1])
        	allSockets = ClientsManager.GetAll()
        	for x in teamData["Members"]:
        		fields["Socket"] = allSockets[int(x)]["Socket"]
        		Messaging.sendMessage(24124, fields, calling_instance.player)
        		Messaging.sendMessage(24131, fields, calling_instance.player)


    def getMessageType(self):
        return 14479


    def getMessageVersion(self):
        return self.messageVersion
