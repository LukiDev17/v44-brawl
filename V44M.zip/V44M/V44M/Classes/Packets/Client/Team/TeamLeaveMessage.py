from Classes.ByteStream import ByteStream
from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler, TeamDatabaseHandler
from Classes.Messaging import Messaging
import json


class TeamLeaveMessage(PiranhaMessage):


    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0


    def encode(self, fields, player):
        pass

    def decode(self):
        fields = {}
        super().decode(fields)
        return fields


    def execute(message, calling_instance, fields):
        teamdb_instance = TeamDatabaseHandler()
        teamData = json.loads(teamdb_instance.getTeamWithLowID(calling_instance.player.TeamID[1])[0][1])
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        
        Owner = teamData["Members"][str(player_data["ID"][1])]["Owner"]
        allSockets = ClientsManager.GetAll()
        if len(teamData["Members"]) != 1 and Owner != True:
        	LastMessageID = len(teamData["ChatData"])
        	message = {
        	'StreamType': 4,
        	'StreamID': [0, LastMessageID + 1],
        	'PlayerID': calling_instance.player.ID,
        	'PlayerName': calling_instance.player.Name,
        	'PlayerRole': 0,
        	'EventType': 103,
        	'Target': {'ID': calling_instance.player.ID, 'Name': calling_instance.player.Name}
        	}
        	teamData["ChatData"].append(message)
        	del teamData["Members"][str(player_data["ID"][1])]
        	teamdb_instance.updateTeamData(teamData, calling_instance.player.TeamID[1])
        	player_data["TeamID"] = [0, 0]
        	db_instance.updatePlayerData(player_data, calling_instance)
        	for x in teamData["Members"]:
        		if int(x) in allSockets:
        			fields["Socket"] = allSockets[int(x)]["Socket"]
        			Messaging.sendMessage(24124, fields, calling_instance.player)
        			Messaging.sendMessage(24131, fields, calling_instance.player)
        	fields["Socket"] = calling_instance.client
        	Messaging.sendMessage(24125, fields, calling_instance.player)
        elif Owner == True and len(teamData["Members"]) != 1:
        	LastMessageID = len(teamData["ChatData"])
        	message = {
        	'StreamType': 4,
        	'StreamID': [0, LastMessageID + 1],
        	'PlayerID': calling_instance.player.ID,
        	'PlayerName': calling_instance.player.Name,
        	'PlayerRole': 0,
        	'EventType': 103,
        	'Target': {'ID': calling_instance.player.ID, 'Name': calling_instance.player.Name}
        	}
        	teamData["ChatData"].append(message)
        	del teamData["Members"][str(player_data["ID"][1])]
        	memberSlot = 0
        	for x in teamData["Members"]:
        		if memberSlot == 0:
        			teamData["Members"][str(x)]["Owner"] = True
        			teamdb_instance.updateTeamData(teamData, calling_instance.player.TeamID[1])
        		if int(x) in allSockets:
        			fields["Socket"] = allSockets[int(x)]["Socket"]
        			Messaging.sendMessage(24124, fields, calling_instance.player)
        			Messaging.sendMessage(24131, fields, calling_instance.player)
        		memberSlot += 1
        	player_data["TeamID"] = [0, 0]
        	db_instance.updatePlayerData(player_data, calling_instance)
        	fields["Socket"] = calling_instance.client
        	Messaging.sendMessage(24125, fields, calling_instance.player)
        elif Owner == True and len(teamData["Members"]) == 1:
        	teamdb_instance.deleteTeam(calling_instance.player.TeamID[1])
        	fields["Socket"] = calling_instance.client
        	Messaging.sendMessage(24125, fields, calling_instance.player)


    def getMessageType(self):
        return 14353


    def getMessageVersion(self):
        return self.messageVersion
