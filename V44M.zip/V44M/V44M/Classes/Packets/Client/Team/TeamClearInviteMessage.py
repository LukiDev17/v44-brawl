from Classes.ByteStream import ByteStream
from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler
from Classes.Messaging import Messaging
from Static.StaticData import StaticData
from Database.DatabaseHandler import TeamDatabaseHandler, DatabaseHandler
from Classes.Instances.Classes.Team import Team
from Classes.Utility import Utility
import json


class TeamClearInviteMessage(PiranhaMessage):


    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0


    def encode(self, fields, player):
        pass

    def decode(self):
        fields = {}
        fields["PlayerID"] = self.readLong()
        super().decode(fields)
        return fields


    def execute(message, calling_instance, fields):
        db_instance = DatabaseHandler()
        teamdb_instance = TeamDatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(fields["PlayerID"])[2])
        teamData = json.loads(teamdb_instance.getTeamWithLowID(calling_instance.player.TeamID[1])[0][1])
        
        del teamData["Invites"][str(fields["PlayerID"][1])]
        teamdb_instance.updateTeamData(teamData, calling_instance.player.TeamID[1])
        allSockets = ClientsManager.GetAll()
        for x in teamData["Members"]:
           if int(x) in allSockets:
           	fields["Socket"] = allSockets[int(x)]["Socket"]
           	Messaging.sendMessage(24124, fields, calling_instance.player)


    def getMessageType(self):
        return 14367


    def getMessageVersion(self):
        return self.messageVersion
