class Team:
    ID = [0, 1]
    Members = {}
    Type = 0
    ChatData = []

    def createTeamData(calling_instance, fields):
        DBData = {
            'HighID': fields["TeamID"][0],
            'LowID': fields["TeamID"][1],
            'Members': {str(calling_instance.player.ID[1]): {'HighID': calling_instance.player.ID[0], 'LowID': calling_instance.player.ID[1], 'Ready': False, 'Owner': True}},
            'Type': fields['roomType'],
            'mapID': fields['mapID'],
            'Invites': {},
            'ChatData': [{'StreamType': 4, 'StreamID': [0, 1], 'PlayerID': calling_instance.player.ID, 'PlayerName': calling_instance.player.Name, 'PlayerRole': 0, 'EventType': 101, 'Target': {'ID': calling_instance.player.ID, 'Name': calling_instance.player.Name}
        	}]
        }
        return DBData