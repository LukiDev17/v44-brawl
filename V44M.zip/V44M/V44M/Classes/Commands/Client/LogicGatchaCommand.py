import json

from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
from Classes.ByteStream import ByteStream
from Classes.Files.Classes.Cards import Cards
from Classes.Files.Classes.Characters import Characters
import random


class LogicGatchaCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        pass

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["box_id"] = calling_instance.readVInt()
        LogicCommand.parseFields(fields)
        return fields

    def execute(self, calling_instance, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        player_data["delivery_items"] = {
        'Boxes': []
        }
        box = {
        'Type': 0,
        'Items': []
        }
        brawlers= list(player_data["OwnedBrawlers"].keys())
        pp1= random.randint(9,127)
        pp2 = random.randint(9,127)
        pp3 = random.randint(9,127)
        pp4 = random.randint(9,127)
        pp5 = random.randint(9,127)
        if fields["box_id"] == 1:
        	ppbr = random.randint(20, 64)
        if fields["box_id"] == 3:
        	ppbr = random.randint(75, 120)
        brawlerID1= random.choice(brawlers)
        brawlerID2 = random.choice(brawlers)
        brawlerID3 = random.choice(brawlers)
        brawlerID4 = random.choice(brawlers)
        brawlerID5 = random.choice(brawlers)
        while brawlerID2 == brawlerID1 or brawlerID2 == brawlerID3:
        	brawlerID2 = random.choice(brawlers)
        while brawlerID3 == brawlerID1 or brawlerID3 == brawlerID2:
        	brawlerID3 = random.choice(brawlers)
        if len(brawlers) >= 4:
        			while brawlerID4 == brawlerID1 or brawlerID4 == brawlerID2 or brawlerID4 == brawlerID3 or brawlerID4 == brawlerID5:
        				brawlerID4 = random.choice(brawlers)
        if len(brawlers) >= 5:
        			while brawlerID5 == brawlerID1 or brawlerID5 == brawlerID2 or brawlerID5 == brawlerID3 or brawlerID5 == brawlerID4:
        				brawlerID5 = random.choice(brawlers)
        if len(brawlers) != len(Characters.getBrawlersID()):
        	brawlerID6 = random.randint(0, 59)
        	while brawlerID6 == 33 or brawlerID6 == 55 or str(brawlerID6) in brawlers:
        		brawlerID6 = random.randint(0, 59)
        if fields["box_id"] == 1:
        	gold = random.randint(21, 134)
        if fields["box_id"] == 3:
        	gold = random.randint(53, 271)
        if random.randint(0, 10) == 7:
        	gems = random.randint(30, 90)
        elif random.randint(0, 5) == 2:
        	gems = random.randint(20, 50)
        else:
        	gems = random.randint(5, 30)
        if fields["box_id"] == 1:
        	box['Type'] = 12
        if fields["box_id"] == 3:
        	box['Type'] = 11
        item = {'Amount': gold, 'DataRef': [0, 0], 'RewardID': 7}
        box['Items'].append(item)
        item = {'Amount': pp1, 'DataRef': [16, brawlerID1], 'RewardID': 6}
        box['Items'].append(item)
        item = {'Amount': pp2, 'DataRef': [16, brawlerID2], 'RewardID': 6}
        box['Items'].append(item)
        item = {'Amount': pp3, 'DataRef': [16, brawlerID3], 'RewardID': 6}
        box['Items'].append(item)
        for i,v in player_data["OwnedBrawlers"].items():
        			if i == str(brawlerID1):
        				v["PowerPoints"] += pp1
        for i,v in player_data["OwnedBrawlers"].items():
        			if i == str(brawlerID2):
        				v["PowerPoints"] += pp2
        for i,v in player_data["OwnedBrawlers"].items():
        			if i == str(brawlerID3):
        				v["PowerPoints"] += pp3
        if fields["box_id"] == 3:
        	if len(brawlers) >= 4:
        		item = {'Amount': pp4, 'DataRef': [16, brawlerID4], 'RewardID': 6}
        		box['Items'].append(item)
        		for i,v in player_data["OwnedBrawlers"].items():
        				if i == str(brawlerID4):
        					v["PowerPoints"] += pp4
        	if len(brawlers) >= 5:
        		item = {'Amount': pp5, 'DataRef': [16, brawlerID5], 'RewardID': 6}
        		box['Items'].append(item)
        		for i,v in player_data["OwnedBrawlers"].items():
        				if i == str(brawlerID5):
        					v["PowerPoints"] += pp5
        if fields["box_id"] == 3:
        	if random.randint(0, 10) == 3:
        	       if len(brawlers) != len(Characters.getBrawlersID()):
        	       	item = {'Amount': 1, 'DataRef': [16, brawlerID6], 'RewardID': 1}
        	       	box['Items'].append(item)
        	       	player_data["OwnedBrawlers"][brawlerID6] = {'CardID': Cards.getBrawlerUnlockID(brawlerID6), 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 1}
        	else:
        	    if random.randint(0, 3) == 2:
        	    	item = {'Amount': ppbr, 'DataRef': [0, 0], 'RewardID': 19}
        	    	box['Items'].append(item)
        if fields["box_id"] == 1:
        	if random.randint(0, 10) == 3:
        	   if len(brawlers) != len(Characters.getBrawlersID()):
        	   	item = {'Amount': 1, 'DataRef': [16, brawlerID6], 'RewardID': 1}
        	   	box['Items'].append(item)
        	   	player_data["OwnedBrawlers"][brawlerID6] = {'CardID': Cards.getBrawlerUnlockID(brawlerID6), 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 1}
        	else:
        	    if random.randint(0, 6) == 2:
        	    	item = {'Amount': ppbr, 'DataRef': [0, 0], 'RewardID': 19}
        	    	box['Items'].append(item)
        if random.randint(0, 3) == 2:
        	item = {'Amount': gems, 'DataRef': [0, 0], 'RewardID': 8}
        	box['Items'].append(item)
        	player_data["Gems"] += gems
        if fields["box_id"] == 1:
        	player_data["Gems"] -= 30
        if fields["box_id"] == 3:
        	player_data["Gems"] -= 80
        player_data["Coins"] += gold
        player_data["delivery_items"]['Boxes'].append(box)
        if fields["box_id"] == 1 and player_data["Gems"] >= 30 or fields["box_id"] == 3 and player_data["Gems"] >= 80:
        	db_instance.updatePlayerData(player_data, calling_instance)
        	fields["Socket"] = calling_instance.client
        	fields["Command"] = {"ID": 203}
        	fields["PlayerID"] = calling_instance.player.ID
        	Messaging.sendMessage(24111, fields)


    def getCommandType(self):
        return 500