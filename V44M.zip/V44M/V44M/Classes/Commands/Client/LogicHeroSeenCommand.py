import json

from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
from Classes.ByteStream import ByteStream
import random


class LogicHeroSeenCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        pass

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["BrawlerID"] = calling_instance.readDataReference()
        return fields

    def execute(self, calling_instance, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        brawler = fields["BrawlerID"][1]
        for i,v in player_data["OwnedBrawlers"].items():
            if i == str(brawler):
            	State = v["State"]
            	v["State"] = 2
        if State != 2:
        	db_instance.updatePlayerData(player_data, calling_instance)


    def getCommandType(self):
        return 522