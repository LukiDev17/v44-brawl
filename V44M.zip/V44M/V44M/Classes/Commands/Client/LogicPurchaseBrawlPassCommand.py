import json

from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
import Configuration


class LogicPurchaseBrawlPassCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        pass

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["BPSeason"] = calling_instance.readVInt()
        fields["Unk"] = calling_instance.readVInt()
        LogicCommand.parseFields(fields)
        return fields

    def execute(self, calling_instance, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        BP = player_data["BPActivated"]
        player_data["BPActivated"] = True
        try:
        	player_data["Notifications"]
        except KeyError:
        	player_data["Notifications"] = []
        notification = {"Type": 71, "Readed": False, "Timer": 0, "Text": "Thanks for pushing BrawlPass", "BPSeason": Configuration.settings["CurrentBPSeason"], "Tokens": 5000, "Number": len(player_data["Notifications"]) + 1}
        player_data["Notifications"].append(notification)
        if BP != True:
        	db_instance.updatePlayerData(player_data, calling_instance)
        	fields["Notification"] = notification
        	fields["Socket"] = calling_instance.client
        	fields["Command"] = {"ID": 206}
        	Messaging.sendMessage(24111, fields)

    def getCommandType(self):
        return 534