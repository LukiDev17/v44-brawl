import csv
import Configuration


class Pins:

    def getPinsID():
        EmotesID = []
        with open('Classes/Files/assets/csv_logic/emotes.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            for row in csv_reader:
                if line_count == 0 or line_count == 1:
                    line_count += 1
                else:
                    if row[1].lower() != 'true':
                        EmotesID.append(line_count - 2)
                    if row[0] != "":
                        line_count += 1

            return EmotesID

    def getSkinPin(skinID):
        with open('Classes/Files/assets/csv_logic/skins.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            for row in csv_reader:
                if line_count == 0 or line_count == 1:
                    line_count += 1
                else:
                    if line_count - 2 == skinID:
                        nameSkin = row[0]
                        emotes_file = open('Classes/Files/assets/csv_logic/emotes.csv')
                        csv_reader2 = csv.reader(emotes_file, delimiter=',')
                        line_count2 = 0
                        for row2 in csv_reader2:
                        	if line_count2 == 0 or line_count2 == 1:
                        		line_count2 += 1
                        	else:
                        		if row2[6].lower() == 'true':
                        			SkinName = row2[5]
                        			if SkinName == nameSkin:
                        				EmoteID = line_count2 - 2
                        				return EmoteID
                        		if row2[0] != "":
                        			line_count2 += 1
                    if row[0] != "":
                        line_count += 1
    
    def getSkinsFromPack(PackID):
        with open('Classes/Files/assets/csv_logic/seasonal_skin_sections.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            skins = []
            for row in csv_reader:
                if line_count == 0 or line_count == 1:
                    line_count += 1
                else:
                    if line_count - 1 == PackID:
                        PackName = row[0]
                        skins_file = open('Classes/Files/assets/csv_logic/skins.csv')
                        csv_reader2 = csv.reader(skins_file, delimiter=',')
                        line_count2 = 0
                        for row2 in csv_reader2:
                        	if line_count2 == 0 or line_count2 == 1:
                        										line_count2 += 1
                        	else:
                        		if row2[3] != "":
                        			if row2[3].lower() == PackName.lower():
                        				if row2[0] == "":
                        					skins.append(line_count2 - 3)
                        				else:
                        					skins.append(line_count2 - 2)
                        		if row2[0] != "" or line_count2 >= 537:
                        			line_count2 += 1
                    if row[0] != "":
                        line_count += 1
            return skins

    def getSkinPinFromPack(skinID):
        with open('Classes/Files/assets/csv_logic/skins.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            for row in csv_reader:
                if line_count == 0 or line_count == 1:
                    line_count += 1
                else:
                    if line_count - 2 == skinID:
                        nameSkin = row[0]
                        emotes_file = open('Classes/Files/assets/csv_logic/emotes.csv')
                        csv_reader2 = csv.reader(emotes_file, delimiter=',')
                        line_count2 = 0
                        for row2 in csv_reader2:
                        	if line_count2 == 0 or line_count2 == 1:
                        		line_count2 += 1
                        	else:
                        		if row2[6] == "" and row2[5] != "":
                        			SkinName = row2[5]
                        			if SkinName.lower() == nameSkin.lower():
                        				EmoteID = line_count2 - 2
                        				return EmoteID
                        		if row2[0] != "":
                        			line_count2 += 1
                    if row[0] != "":
                        line_count += 1