Discord link : https://discord.gg/mt4dUxXryh

ANDROID 1 (MEDIAFIRE) : https://www.mediafire.com/file/biid9ttuhiyeaoi/com.projectbsds.v44226.apk/file

ANDROID 2 (GOOGLE DRIVE) : https://drive.google.com/file/d/1zKy632blJDJV7YuBnUZe18Pxpra2lvm5/view?usp=sharing

Server ZIP: https://github.com/CrazorTheCat/BSDS-V44/archive/refs/heads/master.zip

## Requirements: ##
1. a brain...

## How to play BSDS: ##
1. download server and apk
2. install the apk
3. download pydroid (if you want to run from the phone)
4. open in pydroid Core.py located in the server folder
5. click on the run button
6. now open the game and play

## Change the ip address and port (if needed) in libprojectbsds.config.so located in the lib folder of the apk ##

![bsdsv44](https://user-images.githubusercontent.com/52799759/176961091-0fe7c802-5ad5-433e-9e36-edec5545f492.png)
